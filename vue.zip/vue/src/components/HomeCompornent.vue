<template>
    <div id="HomeCompornent">
        <h1>よい子のメイン画面</h1>
        <div class="row">
            <div v-on:click="goBioHazard">
                <sub-compornent :total=1 subTitle="バイオハザード" subColor="#e0ebaf"></sub-compornent>
            </div>
            <div v-on:click="goWescar">
              <sub-compornent :total=14 subTitle="ウェスカー" subColor="#f5e56b"></sub-compornent>
            </div>
          </div>
        <div class="row">
            <sub-compornent :total=8 subTitle="イヴリン" subColor="#ee827c"></sub-compornent>
            <sub-compornent :total=5 subTitle="ビリー" subColor="#a2d7dd"></sub-compornent>
        </div>
    </div>
</template>

<script>

import SubCompornent from './SubCompornent.vue';

export default {
  name: 'HomeCompornent',
  components: {
    SubCompornent
  },

  methods:{
    goBioHazard :function(){
        console.log("バイオハザードをクリック")
        this.$emit('handOverParent', "bio");
    },
    goWescar :function(){
      this.$emit('handOverParent', "wes");
    }
  }
}
</script>

<style>
#main {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: whitesmoke;
  /*margin-top: 60p*/
  background-color: #2c3e50;
}
.row{
    display: flex;
}
</style>
