<template>
    <div class="sub_common" v-bind:style="{backgroundColor: subColor}">
        <h2>{{ subTitle }}</h2>
        <p class="my-comp">トータルの値{{ total }}</p>
    </div>
</template>
<script>
export default {
    name:'SubCompornent',
    props: {
        subTitle:String,
        subColor:String,
        total: Number 
    }
}

</script>

<style scoped>
    div {
        border: 1em;
    }
</style>