<template>
  <div>
    <h1>ウェスカー</h1>
    <p>ゲーム版とネトフリ版で人種違くない？？</p>
    <div v-on:click="goHome">   modoru </div>
  </div>
</template>

<script>
export default {
    name: 'WescarCompornent',
    methods:{
    goHome :function(){
        console.log("戻るをクリック")
        this.$emit('handOverParent', "home");
    }
  }
}
</script>

<style>

</style>