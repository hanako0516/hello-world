<template>
  <div>
    <h1>バイオハザーード</h1>
    <div>時系列が行ったり来たりしてる気がする。<br>
    なんか難しい
    </div>
    <div v-on:click="goHome">   modoru </div>
  </div>
</template>

<script>
export default {
    name: 'BioHazard',
    methods:{
    goHome :function(){
        console.log("戻るをクリック")
        this.$emit('handOverParent', "home");
    }
  }
}
</script>

<style>

</style>