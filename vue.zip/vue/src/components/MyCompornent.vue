<template>
    <p class="my-comp">Hello</p>
</template>
<script>
export default {
    name:'MyCompornent'
}
</script>