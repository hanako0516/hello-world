<template>
  <div id="app">
    
    <home-compornent @handOverParent="changeSub" v-if="this.currentComponent === 'home'"></home-compornent>
    <bio-hazard @handOverParent="changeSub" v-if="this.currentComponent === 'bio'"></bio-hazard>
    <wescar-compornent @handOverParent="changeSub" v-if="this.currentComponent === 'wes'"></wescar-compornent>
  </div>
</template>

<script>
import HomeCompornent from "./components/HomeCompornent.vue";
import BioHazard from "./components/details/BioHazard.vue";
import WescarCompornent from "./components/details/WescarCompornent.vue";

export default {
  name: "App",
  components: {
    HomeCompornent,
    BioHazard,
    WescarCompornent
  },
  data() {
    return {
      currentComponent: "home",
    };
  },
  methods:{
    changeSub(val){
        this.currentComponent = val;
    }
  }
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: whitesmoke;
  /*margin-top: 60p*/
  background-color: #2c3e50;
}
.row {
  display: flex;
}
</style>
